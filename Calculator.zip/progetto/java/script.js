
 function n(dato){ 
   document.getElementById("operazioni").value+=dato};

function operazione() { 
document.getElementById("operazioni").value=eval(document.getElementById("operazioni").value)};

function cancella() { 
 document.getElementById("operazioni").value=""};

function isSymbol(s) {
    if(s=='+'|| s=='-' || s=='/' || s=='*' || s=='.'){
        return true;
    }else{
        return false;
    }
}

function reset() {
    let operazione = document.getElementById("operazioni")
    risultato.value = ""
}

function total() {
    let result = document.getElementById("operazioni")
    let total = eval(res.value)
    res.value = total
}
 
